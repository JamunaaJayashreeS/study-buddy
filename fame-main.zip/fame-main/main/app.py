from flask import Flask, render_template, request, redirect, url_for, session
from flask import Flask, jsonify
from flask_cors import CORS, cross_origin

import re

app = Flask(__name__)
CORS(app, support_credentials=True)
@app.route('/')
@app.route('/login', methods =['GET', 'POST'])
def login():
    msg = 'Hii'
    return msg
if __name__ == "__main__":
    app.run(host ="localhost", port = int("5000"))